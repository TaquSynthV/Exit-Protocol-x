﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class LanternManager : MonoBehaviour
{
    public static LanternManager Instance { get; private set; }

    public int requiredCount = 6;
    public GameObject brokenPillarObject;
    public GameObject glowingPillarPrefab;
    public PropsAltar altar;

    [Header("Audio")]
    [SerializeField] private AudioClip pillarRestoreSE;
    [SerializeField] private AudioMixerGroup mixerGroup;
    [SerializeField] private float seVolume = 1.0f;

    private bool pillarReplaced = false;
    private List<int> correctOrder = new();
    private int currentIndex = 0;
    private List<StoneLanternButton> allLanterns = new();

    private void Awake()
    {
        if (Instance != null) Destroy(gameObject);
        Instance = this;
        GenerateRandomOrder();
    }

    private void Start()
    {
        allLanterns = new List<StoneLanternButton>(
            FindObjectsByType<StoneLanternButton>(FindObjectsSortMode.None)
        );

        AssignRandomLanternIDs();
        GenerateRandomOrder();
    }

    private void GenerateRandomOrder()
    {
        correctOrder.Clear();
        List<int> ids = new();
        foreach (var lantern in allLanterns)
        {
            ids.Add(lantern.lanternID);
        }

        // シャッフルして正解順を作る
        for (int i = 0; i < requiredCount && i < ids.Count; i++)
        {
            correctOrder.Add(ids[i]);
        }

        Debug.Log("石灯籠正解順: " + string.Join(", ", correctOrder));
    }

    public void CheckLanternInput(int pressedID, StoneLanternButton button)
    {
        // ✅ 光る柱が復活済みなら何も処理しない（ログも出さない）
        if (pillarReplaced) return;

        // ✅ すでに正解済みのIDだったら通知して終了
        if (correctOrder.IndexOf(pressedID) < currentIndex)
        {
            ChatLogger.Instance?.Log($"石灯籠：「{pressedID}」は既に正解済み", "lantern");
            return;
        }

        // ✅ 正しい順番の灯籠を押した
        if (currentIndex < correctOrder.Count && pressedID == correctOrder[currentIndex])
        {
            currentIndex++;
            ChatLogger.Instance?.Log($"正解の灯籠を押した！（{currentIndex}/{requiredCount}）", "lantern");

            if (currentIndex >= requiredCount)
            {
                pillarReplaced = true;
                ReplaceBrokenPillar();
                altar?.ActivateRunes();
                ChatLogger.Instance?.Log("正しい順番で押した！柱が復活！", "lantern");
            }
        }
        else
        {
            ChatLogger.Instance?.Log("順番通りに押してください。", "lantern-warning");
        }
    }

    private void ReplaceBrokenPillar()
    {
        if (brokenPillarObject == null || glowingPillarPrefab == null)
        {
            Debug.LogError("柱または光る柱のプレハブが未設定です！");
            return;
        }

        Vector3 pos = brokenPillarObject.transform.position;
        Quaternion rot = brokenPillarObject.transform.rotation;

        Destroy(brokenPillarObject);
        Instantiate(glowingPillarPrefab, pos, rot);

        PlayPillarRestoreSE(pos);
    }

    private void PlayPillarRestoreSE(Vector3 position)
    {
        if (pillarRestoreSE == null) return;

        GameObject seObject = new GameObject("TempPillarSE");
        seObject.transform.position = position;

        AudioSource audioSource = seObject.AddComponent<AudioSource>();
        audioSource.clip = pillarRestoreSE;
        audioSource.volume = seVolume;
        audioSource.spatialBlend = 0f;

        if (mixerGroup != null)
            audioSource.outputAudioMixerGroup = mixerGroup;

        audioSource.Play();
        Destroy(seObject, pillarRestoreSE.length);
    }

    private void AssignRandomLanternIDs()
    {
        List<int> ids = new();
        for (int i = 0; i < allLanterns.Count; i++) ids.Add(i);

        for (int i = 0; i < ids.Count; i++)
        {
            int rand = Random.Range(i, ids.Count);
            (ids[i], ids[rand]) = (ids[rand], ids[i]);
        }

        for (int i = 0; i < allLanterns.Count; i++)
        {
            allLanterns[i].lanternID = ids[i];
        }
    }

    public void ShowCorrectOrder()
    {
        if (correctOrder == null || correctOrder.Count == 0)
        {
            ChatLogger.Instance?.Log("まだ正解の順番が生成されていません。", "hint-error");
            return;
        }

        string hintText = "石灯籠正解順: " + string.Join(" → ", correctOrder);
        ChatLogger.Instance?.Log(hintText, "hint");
        Debug.Log(hintText);
    }

    // ✅ 外部から柱の状態を確認する用
    public bool IsPillarReplaced()
    {
        return pillarReplaced;
    }
}
