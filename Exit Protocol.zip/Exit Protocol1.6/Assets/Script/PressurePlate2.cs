using UnityEngine;

public class PressurePlate2 : MonoBehaviour
{
    public BellManager manager;
    private bool hasActivated = false; // ��x�����������邽�߂̃t���O

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (hasActivated) return;

        if (other.CompareTag("Player"))
        {
            hasActivated = true;
            manager.StartPuzzle();
        }
    }
}
