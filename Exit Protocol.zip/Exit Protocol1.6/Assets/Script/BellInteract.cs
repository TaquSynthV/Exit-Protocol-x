﻿using UnityEngine;

public class BellInteract : MonoBehaviour, IInteractable
{
    public int bellIndex; // BellManager が Start 時にランダム割り当て
    public BellManager manager;
    private AudioSource audioSource;

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null) Debug.LogError($"{name}: AudioSource が見つかりません！");
        if (manager == null) Debug.LogError($"{name}: BellManager が未設定です！");
    }

    public void Interact()
    {
        Debug.Log($"{name}: Interact 実行");

        if (manager != null && bellIndex >= 0 && bellIndex < manager.bellSounds.Length)
        {
            if (audioSource != null && manager.bellSounds[bellIndex] != null)
                audioSource.PlayOneShot(manager.bellSounds[bellIndex]);

            manager.BellPressed(bellIndex);
        }
        else
        {
            Debug.LogWarning($"{name}: ベルの設定が正しくありません！");
        }
    }
}
