﻿using UnityEngine;
using UnityEngine.Audio;

public class StoneLanternButton : MonoBehaviour, IInteractable
{
    [Header("設定")]
    public int lanternID; // ランダム順でチェックされるID

    [Header("Audio Settings")]
    [SerializeField] private AudioClip pressSE;
    [SerializeField] private AudioMixerGroup outputMixerGroup;
    [SerializeField] private float seVolume = 1.0f;
    [SerializeField] private float delayBeforeAction = 0.3f;

    public void Interact()
    {
        // ✅ 光る柱が復活済みなら他のログも出さず終了
        if (LanternManager.Instance != null && LanternManager.Instance.IsPillarReplaced())
        {
            ChatLogger.Instance?.Log("石灯籠を押す必要はありません。", "lantern-info");
            return;
        }

        Debug.Log($"石灯籠（ID:{lanternID}）を押した！");
        ChatLogger.Instance?.Log($"石灯籠：「{lanternID}」を押した", "lantern");
        PlaySEWithDelay();
    }

    private void PlaySEWithDelay()
    {
        if (pressSE != null)
        {
            GameObject seObject = new GameObject("TempLanternSE");
            seObject.transform.position = transform.position;

            AudioSource audioSource = seObject.AddComponent<AudioSource>();
            audioSource.clip = pressSE;
            audioSource.volume = seVolume;
            audioSource.spatialBlend = 0f;

            if (outputMixerGroup != null)
                audioSource.outputAudioMixerGroup = outputMixerGroup;

            audioSource.Play();
            Destroy(seObject, pressSE.length);
        }

        Invoke(nameof(RegisterLantern), delayBeforeAction);
    }

    private void RegisterLantern()
    {
        LanternManager.Instance.CheckLanternInput(lanternID, this);
    }
}
