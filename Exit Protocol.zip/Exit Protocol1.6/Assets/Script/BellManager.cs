using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BellManager : MonoBehaviour
{
    [Header("Audio")]
    public AudioClip[] bellSounds; // �x���̉��i��F5�j
    public AudioSource audioSource;

    [Header("Puzzle Settings")]
    public int bellCount = 5; // bellInteractList.Count �Ɠ����ɂ���

    [Header("Spawn Objects")]
    public GameObject chestPrefab;
    public Transform chestSpawnPoint;

    [Tooltip("�V�[���ɒ��ڔz�u���ꂽ�|�[�^���I�u�W�F�N�g���w��i�ŏ��͔�A�N�e�B�u�ɂ��Ă����j")]
    public GameObject portalObject;

    [Header("�x���̐ݒ�")]
    public List<BellInteract> bellInteractList; // �V�[����̃x��5��o�^

    private List<int> correctSequence = new List<int>();
    private List<int> playerInput = new List<int>();
    private bool isPlayingSequence = false;
    private bool puzzleSolved = false;

    private List<int> randomizedBellIndices = new List<int>();

    private void Start()
    {
        if (portalObject != null)
        {
            portalObject.SetActive(false);
        }

        // bellCount �̓V�[���̃x�����ɍ��킹��
        bellCount = bellInteractList.Count;

        AssignRandomBellIndices();
    }

    private void AssignRandomBellIndices()
    {
        randomizedBellIndices.Clear();
        for (int i = 0; i < bellCount; i++)
        {
            randomizedBellIndices.Add(i);
        }

        // �V���b�t��
        for (int i = 0; i < randomizedBellIndices.Count; i++)
        {
            int temp = randomizedBellIndices[i];
            int randomIndex = Random.Range(i, randomizedBellIndices.Count);
            randomizedBellIndices[i] = randomizedBellIndices[randomIndex];
            randomizedBellIndices[randomIndex] = temp;
        }

        // �e BellInteract �Ɉ�ӂ� bellIndex �����蓖��
        for (int i = 0; i < bellInteractList.Count && i < randomizedBellIndices.Count; i++)
        {
            bellInteractList[i].bellIndex = randomizedBellIndices[i];
        }
    }

    // �^�O�t�����O�o�̓��b�p�[
    private void LogWithTag(string message, string tag)
    {
        ChatLogger.Instance?.Log(message, tag);
    }

    public void StartPuzzle()
    {
        if (isPlayingSequence || puzzleSolved) return;

        correctSequence.Clear();
        playerInput.Clear();

        for (int i = 0; i < bellCount; i++)
        {
            int randomBellObjIndex = Random.Range(0, bellInteractList.Count);
            int bellIndex = bellInteractList[randomBellObjIndex].bellIndex;

            if (bellIndex >= 0 && bellIndex < bellSounds.Length)
            {
                correctSequence.Add(bellIndex);
            }
        }

        LogWithTag("�x���̉����o���悤�I", "info");
        StartCoroutine(PlaySequence());
    }

    private IEnumerator PlaySequence()
    {
        isPlayingSequence = true;

        int playCount = 0;
        foreach (int index in correctSequence)
        {
            if (index >= 0 && index < bellSounds.Length)
            {
                audioSource.PlayOneShot(bellSounds[index]);
                LogWithTag($"�x�� {index + 1} �̉�����܂���", $"bell_sound_{index}_{playCount}");
            }

            playCount++;
            yield return new WaitForSeconds(1.0f);
        }

        isPlayingSequence = false;
        LogWithTag("�x�������Ԃɖ炵�Ă��������I", "info");
    }

    public void BellPressed(int bellIndex)
    {
        if (isPlayingSequence || puzzleSolved) return;

        if (bellIndex < 0 || bellIndex >= bellSounds.Length)
        {
            return;
        }

        audioSource.PlayOneShot(bellSounds[bellIndex]);
        playerInput.Add(bellIndex);
        LogWithTag($"�x�� {bellIndex + 1} ��炵�܂���", $"bell_pressed_{bellIndex}_{playerInput.Count}");

        if (playerInput.Count > correctSequence.Count)
        {
            playerInput.Clear();
            return;
        }

        int i = playerInput.Count - 1;
        if (playerInput[i] != correctSequence[i])
        {
            LogWithTag("�ŏ������蒼���Ă�������", "error");
            playerInput.Clear();
            return;
        }

        if (playerInput.Count == correctSequence.Count)
        {
            PuzzleClear();
        }
    }

    private void PuzzleClear()
    {
        puzzleSolved = true;
        LogWithTag("�����I�󔠂ƃ|�[�^�����o������", "success");

        if (chestPrefab != null && chestSpawnPoint != null)
        {
            Instantiate(chestPrefab, chestSpawnPoint.position, Quaternion.identity);
        }

        if (portalObject != null)
        {
            portalObject.SetActive(true);
        }
    }
}
