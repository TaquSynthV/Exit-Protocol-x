﻿using UnityEngine;
using UnityEngine.Audio;

namespace Cainos.PixelArtTopDown_Basic
{
    public class TopDownCharacterController : MonoBehaviour
    {
        [Header("Movement")]
        public float speed = 3f;
        public float interactRange = 1f;

        [Header("Attack")]
        public GameObject attackHitboxPrefab;
        public float attackDuration = 0.2f;     // 攻撃ヒットボックス存続時間

        [Header("Footstep SE")]
        public AudioClip footstepSE;
        public AudioMixerGroup mixerGroup;
        [Range(0f, 1f)] public float footstepVolume = 0.4f;

        [Header("Raycast")]
        [SerializeField] private LayerMask interactableMask; // 「Interactable」レイヤーのみ選択

        // ──────────────────────────────────────
        private AudioSource footstepSource;
        private Animator animator;
        private Vector2 lastDirection = Vector2.down;
        private Rigidbody2D rb;
        private PushableObject pullingTarget;

        // ──────────────────────────────────────
        private void Start()
        {
            animator = GetComponent<Animator>();
            rb = GetComponent<Rigidbody2D>();

            // 足音用 AudioSource
            footstepSource = gameObject.AddComponent<AudioSource>();
            footstepSource.clip = footstepSE;
            footstepSource.loop = true;
            footstepSource.volume = footstepVolume;
            footstepSource.playOnAwake = false;
            footstepSource.spatialBlend = 0f;
            if (mixerGroup) footstepSource.outputAudioMixerGroup = mixerGroup;
        }

        // ──────────────────────────────────────
        [System.Obsolete]
        private void Update()
        {
            //
            // 1. 移動入力
            //
            Vector2 dir = Vector2.zero;

            if (Input.GetKey(KeyCode.A)) { dir.x = -1; animator.SetInteger("Direction", 3); }
            else if (Input.GetKey(KeyCode.D)) { dir.x = 1; animator.SetInteger("Direction", 2); }

            if (Input.GetKey(KeyCode.W)) { dir.y = 1; animator.SetInteger("Direction", 1); }
            else if (Input.GetKey(KeyCode.S)) { dir.y = -1; animator.SetInteger("Direction", 0); }

            if (dir != Vector2.zero) lastDirection = dir;
            dir.Normalize();
            rb.velocity = speed * dir;

            // 足音
            if (dir.sqrMagnitude > 0f)
            {
                if (!footstepSource.isPlaying && footstepSE) footstepSource.Play();
            }
            else if (footstepSource.isPlaying) footstepSource.Stop();

            //
            // 2. プル（左クリック押しっぱなし）
            //
            if (Input.GetMouseButton(0))
            {
                if (pullingTarget == null) TryStartPull();
            }
            else if (pullingTarget)
            {
                pullingTarget.StopPull();
                pullingTarget = null;
            }

            //
            // 3. インタラクト / 攻撃
            //
            if (Input.GetKeyDown(KeyCode.E))
            {
                Interact();
            }

            if (Input.GetKeyDown(KeyCode.Q) || Input.GetMouseButtonDown(1)) // Qキー or 右クリック
            {
                Attack();
            }
        }

        // ──────────────────────────────────────
        private void Interact()
        {
            Vector2 rayDir = GetDirectionVector();
            Vector2 origin = (Vector2)transform.position + rayDir * 0.4f;

            RaycastHit2D hit = Physics2D.Raycast(origin, rayDir, interactRange, interactableMask);
            Debug.DrawRay(origin, rayDir * interactRange, Color.red, 0.5f);

            if (!hit) return;
            if (hit.collider.TryGetComponent<IInteractable>(out var obj))
                obj.Interact();
        }

        private void Attack()
        {
            if (!attackHitboxPrefab) return;

            Vector2 attackDir = GetDirectionVector();
            Vector2 spawnPos = (Vector2)transform.position + attackDir * 0.5f;

            GameObject hitbox = Instantiate(attackHitboxPrefab, spawnPos, Quaternion.identity);
            Destroy(hitbox, attackDuration);
        }

        private Vector2 GetDirectionVector()
        {
            return animator.GetInteger("Direction") switch
            {
                0 => Vector2.down,
                1 => Vector2.up,
                2 => Vector2.right,
                3 => Vector2.left,
                _ => Vector2.down
            };
        }

        private void TryStartPull()
        {
            Vector2 rayDir = GetDirectionVector();
            Vector2 origin = (Vector2)transform.position + rayDir * 0.4f;

            RaycastHit2D hit = Physics2D.Raycast(origin, rayDir, interactRange, interactableMask);
            if (!hit) return;

            if (hit.collider.TryGetComponent<PushableObject>(out var pushable))
            {
                pullingTarget = pushable;
                pushable.StartPull(transform);
            }
        }
    }
}
