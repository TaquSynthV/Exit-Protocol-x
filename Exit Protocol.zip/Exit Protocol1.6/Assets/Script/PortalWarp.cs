using UnityEngine;
using UnityEngine.Audio;

public class PortalWarp : MonoBehaviour
{
    [Header("���[�v���Transform")]
    public Transform warpTarget;

    [Header("�|�[�^����SE")]
    public AudioClip portalSE;
    public AudioSource audioSource;

    [Header("SE�̃~�L�T�[")]
    public AudioMixerGroup seMixerGroup;

    private void Start()
    {
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }

        audioSource.outputAudioMixerGroup = seMixerGroup;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("�|�[�^���ɐG��܂���");

            // �����Đ�
            if (portalSE != null)
            {
                audioSource.PlayOneShot(portalSE);
            }

            // �v���C���[���ړ�
            other.transform.position = warpTarget.position;
        }
    }
}
