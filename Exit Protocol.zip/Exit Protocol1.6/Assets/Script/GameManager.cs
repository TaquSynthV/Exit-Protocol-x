﻿using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    // プレイヤーのステータス・進行状況
    public bool hasKey = false;
    public int stoneCount = 0;
    public int runeCount = 0;

    public bool hasOpenedChest;
    public bool hasOpenedRuneChest;
    public bool goddessUsed;
    public bool pillarFixed;

    public int runePotIndex = -1;
    public bool runePotCollected = false;

    // ワープゲート（ポータル）の参照
    public GameObject portalWarp;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // 石の取得
    public void AddStone()
    {
        stoneCount++;
        Debug.Log($"石を拾った！現在の数: ({stoneCount}/6)");
        ChatLogger.Instance?.Log($"石を拾った！({stoneCount}/6)", "stone");
    }

    // ルーンの取得
    public void AddRune()
    {
        runeCount++;
        Debug.Log($"ルーンを手に入れた！現在の数: ({runeCount}/4)");
        ChatLogger.Instance?.Log($"ルーンを手に入れた！（{runeCount}/4）", "rune");

        if (runeCount == 3 && portalWarp != null)
        {
            portalWarp.SetActive(true);
            Debug.Log("ワープゲートが出現した！");
            ChatLogger.Instance?.Log("ワープゲートが出現した！", "event"); // ← ここを追加
        }
}

// 現在のデータを SaveData に変換して返す
public SaveData GetCurrentSaveData()
    {
        SaveData data = new SaveData
        {
            runeCount = runeCount,
            stoneCount = stoneCount,
            hasKey = hasKey,
            hasOpenedChest = hasOpenedChest,
            hasOpenedRuneChest = hasOpenedRuneChest,
            goddessUsed = goddessUsed,
            pillarFixed = pillarFixed,
            runePotIndex = runePotIndex,
            runePotCollected = runePotCollected,
            playerPosition = GameObject.FindGameObjectWithTag("Player").transform.position,
            destroyedObjectIDs = DestroyedObjectTracker.Instance?.GetDestroyedObjectIDs() ?? new List<string>()
        };

        return data;
    }

    // SaveData から現在のゲーム状態を復元
    public void LoadFromData(SaveData data)
    {
        runeCount = data.runeCount;
        stoneCount = data.stoneCount;
        hasKey = data.hasKey;
        hasOpenedChest = data.hasOpenedChest;
        hasOpenedRuneChest = data.hasOpenedRuneChest;
        goddessUsed = data.goddessUsed;
        pillarFixed = data.pillarFixed;
        runePotIndex = data.runePotIndex;
        runePotCollected = data.runePotCollected;

        DestroyedObjectTracker.Instance?.LoadFrom(data.destroyedObjectIDs);

        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            player.transform.position = data.playerPosition;
        }
        else
        {
            Debug.LogWarning("プレイヤーが見つかりませんでした。Tagが 'Player' になっているか確認してください。");
        }
    }
}
