using UnityEngine;

public class GateActivator : MonoBehaviour
{
    public GameObject gate;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && Inventory.Instance.hasRune)
        {
            gate.SetActive(true);
            this.enabled = false; // ��x����Ȃ疳����
        }
    }
}
