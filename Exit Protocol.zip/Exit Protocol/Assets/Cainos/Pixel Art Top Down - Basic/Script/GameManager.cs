using System;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Progress Info")]
    public int stoneCount = 0;
    public bool statueRepaired = false;
    public bool treasureOpened = false;
    internal bool hasKey;

    private void Awake()
    {
        // �V���O���g���̊m��
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject); // �V�[���Ԃŕێ�
    }

    public void AddStone(int amount)
    {
        stoneCount += amount;

        Debug.Log($"Stone collected! Total: {stoneCount}");

        if (stoneCount >= 6 && !statueRepaired)
        {
            RepairStatue();
        }
    }

    public void RepairStatue()
    {
        if (statueRepaired) return;

        statueRepaired = true;
        Debug.Log("Statue repaired!");

        // �C�����o��C�x���g�ʒm�������ɒǉ�
    }

    public void OpenTreasure()
    {
        if (treasureOpened) return;

        treasureOpened = true;
        Debug.Log("Treasure opened!");

        // �J�������������ɒǉ�
    }

    public void ResetProgress()
    {
        stoneCount = 0;
        statueRepaired = false;
        treasureOpened = false;
        Debug.Log("Progress reset.");
    }

    internal void AddStone()
    {
        throw new NotImplementedException();
    }
}
