using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public bool hasKey = false;

    public int stoneCount = 0; // �� �ǉ��F�΂̏�����

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void AddStone()
    {
        stoneCount++;
        Debug.Log("�΂��E�����I���݂̐�: " + stoneCount);
    }
}
