using System;

public static class GameEvents
{
    public static event Action OnStatueRepaired;
    public static event Action OnChestOpened;

    public static void StatueRepaired() => OnStatueRepaired?.Invoke();
    public static void ChestOpened() => OnChestOpened?.Invoke();
}
