using UnityEngine;

public class Stairs : MonoBehaviour
{
    private void Start()
    {
        gameObject.SetActive(false);
        GameEvents.OnStatueRepaired += ActivateStairs;
    }

    private void OnDestroy()
    {
        GameEvents.OnStatueRepaired -= ActivateStairs;
    }

    private void ActivateStairs()
    {
        gameObject.SetActive(true);
    }
}
