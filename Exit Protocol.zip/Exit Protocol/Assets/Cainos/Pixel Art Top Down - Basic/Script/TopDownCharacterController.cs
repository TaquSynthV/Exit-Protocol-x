﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Cainos.PixelArtTopDown_Basic
{
    public class TopDownCharacterController : MonoBehaviour
    {
        public float speed;
        public float interactRange = 1f;

        private Animator animator;
        private Vector2 lastDirection = Vector2.down;

        private void Start()
        {
            animator = GetComponent<Animator>();
        }

        private void Update()
        {
            Vector2 dir = Vector2.zero;

            if (Input.GetKey(KeyCode.A))
            {
                dir.x = -1;
                animator.SetInteger("Direction", 3);
            }
            else if (Input.GetKey(KeyCode.D))
            {
                dir.x = 1;
                animator.SetInteger("Direction", 2);
            }

            if (Input.GetKey(KeyCode.W))
            {
                dir.y = 1;
                animator.SetInteger("Direction", 1);
            }
            else if (Input.GetKey(KeyCode.S))
            {
                dir.y = -1;
                animator.SetInteger("Direction", 0);
            }

            if (dir != Vector2.zero)
            {
                lastDirection = dir;
            }

            dir.Normalize();
            animator.SetBool("IsMoving", dir.magnitude > 0);
            GetComponent<Rigidbody2D>().linearVelocity = speed * dir;

            if (Input.GetKeyDown(KeyCode.E))
            {
                Interact();
            }
        }

        private void Interact()
        {
            Vector2 rayDirection = Vector2.down;
            int direction = animator.GetInteger("Direction");

            switch (direction)
            {
                case 0: rayDirection = Vector2.down; break;
                case 1: rayDirection = Vector2.up; break;
                case 2: rayDirection = Vector2.right; break;
                case 3: rayDirection = Vector2.left; break;
            }

            Vector2 origin = (Vector2)transform.position + rayDirection * 0.4f;
            RaycastHit2D hit = Physics2D.Raycast(origin, rayDirection, interactRange);

            Debug.DrawRay(origin, rayDirection * interactRange, Color.red, 0.5f);

            if (hit.collider != null)
            {
                IInteractable interactable = hit.collider.GetComponent<IInteractable>();
                if (interactable != null)
                {
                    interactable.Interact();
                }

                // タグベースでのアイテム処理（例：石、ルーン）
                if (hit.collider.CompareTag("Stone"))
                {
                    Inventory.Instance.AddStone();
                    Destroy(hit.collider.gameObject);
                }
                else if (hit.collider.CompareTag("Rune"))
                {
                    Inventory.Instance.AddRune();
                    Destroy(hit.collider.gameObject);
                }
            }
        }
    }
}
