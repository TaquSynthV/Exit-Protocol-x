﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Cainos.PixelArtTopDown_Basic
{
    public class TopDownCharacterController : MonoBehaviour
    {
        public float speed;
        public float interactRange = 1f;

        private Animator animator;
        private Vector2 lastDirection = Vector2.down; // デフォルトは下向き

        private void Start()
        {
            animator = GetComponent<Animator>();
        }

        private void Update()
        {
            Vector2 dir = Vector2.zero;

            // 入力に応じて移動方向を決定
            if (Input.GetKey(KeyCode.A))
            {
                dir.x = -1;
                animator.SetInteger("Direction", 3); // 左
            }
            else if (Input.GetKey(KeyCode.D))
            {
                dir.x = 1;
                animator.SetInteger("Direction", 2); // 右
            }

            if (Input.GetKey(KeyCode.W))
            {
                dir.y = 1;
                animator.SetInteger("Direction", 1); // 上
            }
            else if (Input.GetKey(KeyCode.S))
            {
                dir.y = -1;
                animator.SetInteger("Direction", 0); // 下
            }

            // 最後に動いた方向を保存（向きを覚えるため）
            if (dir != Vector2.zero)
            {
                lastDirection = dir;
            }

            // 実際の移動処理
            dir.Normalize();
            animator.SetBool("IsMoving", dir.magnitude > 0);
            GetComponent<Rigidbody2D>().linearVelocity = speed * dir;

            // Eキーを押したら調べる
            if (Input.GetKeyDown(KeyCode.E))
            {
                Interact();
            }
        }

        private void Interact()
        {
            // プレイヤーの向き（アニメーションの Direction）に応じて Ray の向きを決定
            Vector2 rayDirection = Vector2.down;
            int direction = animator.GetInteger("Direction");

            switch (direction)
            {
                case 0: rayDirection = Vector2.down; break;
                case 1: rayDirection = Vector2.up; break;
                case 2: rayDirection = Vector2.right; break;
                case 3: rayDirection = Vector2.left; break;
            }

            // プレイヤーの「中心」ではなく、「ちょっと前」から Ray を飛ばす（←ここ重要）
            Vector2 origin = (Vector2)transform.position + rayDirection * 0.4f;

            // Ray を飛ばす（物理的な調べ判定）
            RaycastHit2D hit = Physics2D.Raycast(origin, rayDirection, interactRange);

            // デバッグ用：Sceneビューで赤線で確認
            Debug.DrawRay(origin, rayDirection * interactRange, Color.red, 0.5f);

            if (hit.collider != null)
            {
                IInteractable interactable = hit.collider.GetComponent<IInteractable>();
                if (interactable != null)
                {
                    interactable.Interact();
                }
            }
        }
    }
}

