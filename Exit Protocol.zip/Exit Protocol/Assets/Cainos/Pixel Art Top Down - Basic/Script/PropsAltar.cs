﻿using UnityEngine;

public class PropsAltar : MonoBehaviour
{
    public SpriteRenderer[] runeRenderers;   // 発光ルーン（複数対応）
    public float colorChangeSpeed = 2.0f;

    public GameObject gatePrefab;            // 出現させるポータル or ゲートのプレハブ
    public Transform gateSpawnPoint;         // 出現場所に使う空のオブジェクト

    private float targetAlpha = 0f;
    private bool isActivated = false;
    private bool gateSpawned = false;
    private bool playerOnAltar = false;

    private void Start()
    {
        // 全ルーンの透明度を初期化
        if (runeRenderers == null || runeRenderers.Length == 0)
        {
            Debug.LogWarning("PropsAltar: runeRenderers が未設定です！");
            return;
        }

        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                Color c = renderer.color;
                c.a = 0f;
                renderer.color = c;
            }
        }
    }

    private void Update()
    {
        // ルーンの発光アニメ
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                Color current = renderer.color;
                Color target = new Color(current.r, current.g, current.b, targetAlpha);
                renderer.color = Color.Lerp(current, target, Time.deltaTime * colorChangeSpeed);
            }
        }

        // プレイヤーが上にいて Eキーを押したらゲートを出す
        if (playerOnAltar && isActivated && GameManager.Instance.hasRune && Input.GetKeyDown(KeyCode.E))
        {
            TrySpawnGate();
        }
    }

    // 石灯籠のイベントから呼ばれる
    public void ActivateRunes()
    {
        isActivated = true;
        targetAlpha = 1f;  // ルーンを常時点灯に
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerOnAltar = true;

            if (!isActivated)
                targetAlpha = 1f;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerOnAltar = false;

            if (!isActivated)
                targetAlpha = 0f;
        }
    }

    private void TrySpawnGate()
    {
        if (gateSpawned)
        {
            Debug.Log("ゲートはすでに出現しています。");
            return;
        }

        if (gatePrefab == null || gateSpawnPoint == null)
        {
            Debug.LogWarning("gatePrefab または gateSpawnPoint が設定されていません！");
            return;
        }

        Instantiate(gatePrefab, gateSpawnPoint.position, Quaternion.identity);
        gateSpawned = true;
        Debug.Log("ゲート（ポータル）を出現させました！");
    }
}
