﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    [Header("UI Elements")]
    public GameObject menuUI;
    public GameObject volumePanel;
    public GameObject controlsPanel;
    public GameObject chatScrollUI;

    [Header("Audio")]
    public Slider bgmSlider;
    public Slider seSlider;
    public AudioMixer mixer;

    [Header("Buttons")]
    public Button volumeButton;

    private bool isPaused = false;

    void Start()
    {
        // スライダー初期化
        if (bgmSlider != null)
        {
            bgmSlider.onValueChanged.AddListener(SetBGMVolume);
            if (mixer.GetFloat("BGMVolume", out float bgmDb))
            {
                bgmSlider.value = Mathf.Pow(10f, bgmDb / 20f); // dB → 0～1 に変換
            }
        }

        if (seSlider != null)
        {
            seSlider.onValueChanged.AddListener(SetSEVolume);
            if (mixer.GetFloat("SEVolume", out float seDb))
            {
                seSlider.value = Mathf.Pow(10f, seDb / 20f);
            }
        }

        if (volumeButton != null)
        {
            volumeButton.onClick.AddListener(ToggleVolumePanel);
        }

        // 初期状態でパネル非表示
        if (volumePanel != null) volumePanel.SetActive(false);
        if (controlsPanel != null) controlsPanel.SetActive(false);
        if (menuUI != null) menuUI.SetActive(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
            {
                // どの画面が開いていてもすべて閉じてポーズ解除
                CloseAllPanels();
                TogglePause();
            }
            else
            {
                TogglePause(); // メニューを開く
            }
        }
    }

    public void TogglePause()
    {
        isPaused = !isPaused;

        if (menuUI != null) menuUI.SetActive(isPaused);
        if (chatScrollUI != null) chatScrollUI.SetActive(!isPaused); // ポーズ中は非表示

        Time.timeScale = isPaused ? 0f : 1f;
    }

    public void ReturnToTitle()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Title Scene"); // ※タイトルシーン名は要調整
    }

    public void ToggleVolumePanel()
    {
        bool isActive = volumePanel.activeSelf;

        volumePanel.SetActive(!isActive);
        menuUI.SetActive(isActive); // 音量設定を開くときはメニューを閉じる
    }

    public void SetBGMVolume(float value)
    {
        bool success = mixer.SetFloat("BGMVolume", Mathf.Log10(Mathf.Clamp(value, 0.0001f, 1)) * 20);
        if (!success) Debug.LogWarning("BGMVolume が AudioMixer に見つかりません。");
    }

    public void SetSEVolume(float value)
    {
        bool success = mixer.SetFloat("SEVolume", Mathf.Log10(Mathf.Clamp(value, 0.0001f, 1)) * 20);
        if (!success) Debug.LogWarning("SEVolume が AudioMixer に見つかりません。");
    }

    public void BackToMenu()
    {
        if (volumePanel != null) volumePanel.SetActive(false);
        if (controlsPanel != null) controlsPanel.SetActive(false);
        if (menuUI != null) menuUI.SetActive(true);
    }

    public void ShowControlsPanel()
    {
        if (controlsPanel != null) controlsPanel.SetActive(true);
        if (menuUI != null) menuUI.SetActive(false);
    }

    public void HideControlsPanel()
    {
        if (controlsPanel != null) controlsPanel.SetActive(false);
        if (menuUI != null) menuUI.SetActive(true);
    }

    private void CloseAllPanels()
    {
        if (volumePanel != null) volumePanel.SetActive(false);
        if (controlsPanel != null) controlsPanel.SetActive(false);
    }
}
