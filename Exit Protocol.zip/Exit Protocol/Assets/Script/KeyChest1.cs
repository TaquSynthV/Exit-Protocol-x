﻿using UnityEngine;

public class KeyChest1 : MonoBehaviour, IInteractable
{
    public GameObject openedChestPrefab;     // 開いた宝箱のプレハブ
    public AudioClip openChestSE; // 宝箱を開けたときのSE
    private bool hasOpened = false;

    [SerializeField] private Sprite openedChestSprite;
    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void Interact()
    {
        if (!hasOpened)
        {
            hasOpened = true;
            GameManager.Instance.hasRune = true;
            Debug.Log("ルーンを手に入れた！");

            // 開いた宝箱を生成（見た目変化）
            if (openedChestPrefab != null)
            {
                Instantiate(openedChestPrefab, transform.position, transform.rotation);
            }

            // 自オブジェクト破壊（もしくは非表示にする）
            Destroy(gameObject);

            // スプライト変更（任意）
            if (openedChestSprite != null && spriteRenderer != null)
            {
                spriteRenderer.sprite = openedChestSprite;
            }
        }
    }
}
