using UnityEngine;

public class KeyChest : MonoBehaviour, IInteractable
{
    public GameObject openedChestPrefab;
    public AudioClip openChestSE; // �󔠂��J�����Ƃ���SE
    private bool hasOpened = false;

    [SerializeField] private Sprite openedChestSprite;
    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void Interact()
    {
        if (hasOpened) return;

        hasOpened = true;
        GameManager.Instance.hasKey = true;
        Debug.Log("������ɓ��ꂽ�I");

        // ���ʉ����ő剹�ʂōĐ�
        AudioSource.PlayClipAtPoint(openChestSE, transform.position, 1.0f);

        Instantiate(openedChestPrefab, transform.position, transform.rotation);
        Destroy(gameObject);
    }
}
