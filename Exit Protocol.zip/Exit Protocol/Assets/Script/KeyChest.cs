using UnityEngine;
using UnityEngine.Audio;

public class KeyChest : MonoBehaviour, IInteractable
{
    public GameObject openedChestPrefab;
    public AudioClip openChestSE;
    public AudioMixerGroup mixerGroup;
    public float seVolume = 1.0f;
    public float openDelay = 0.1f;

    private bool hasOpened = false;
    private bool readyToPowerUp = false;

    [SerializeField] private Sprite openedChestSprite;
    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void Interact()
    {
        if (hasOpened)
        {
            if (readyToPowerUp && !GameManager.Instance.isPlayerPoweredUp)
            {
                GameManager.Instance.PowerUpPlayer();
                readyToPowerUp = false;
            }
            return;
        }

        hasOpened = true;
        PlaySEWithMixer(openChestSE, transform.position, mixerGroup);
        Invoke(nameof(OpenChest), openDelay);
    }

    private void OpenChest()
    {
        GameManager.Instance.hasKey = true;
        GameManager.Instance.hasOpenedChest = true;

        Debug.Log("������ɓ��ꂽ�I");
        ChatLogger.Instance?.Log("������ɓ��ꂽ�I");

        if (openedChestPrefab != null)
        {
            Instantiate(openedChestPrefab, transform.position, transform.rotation);
        }

        spriteRenderer.enabled = false;
    }

    private void PlaySEWithMixer(AudioClip clip, Vector3 position, AudioMixerGroup mixer)
    {
        if (clip == null) return;

        GameObject audioObj = new GameObject("TempAudio");
        audioObj.transform.position = position;

        AudioSource audioSource = audioObj.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = seVolume;
        audioSource.spatialBlend = 0f;
        audioSource.outputAudioMixerGroup = mixer;

        audioSource.Play();
        Destroy(audioObj, clip.length);
    }
}
