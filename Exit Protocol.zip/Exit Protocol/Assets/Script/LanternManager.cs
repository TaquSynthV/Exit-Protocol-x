using UnityEngine;

public class LanternManager : MonoBehaviour
{
    public static LanternManager Instance { get; private set; }

    public int requiredCount = 6;
    private int pressedCount = 0;
    private bool pillarReplaced = false;

    public PropsAltar altar;
    public GameObject brokenPillarObject;
    public GameObject glowingPillarPrefab;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void RegisterPressedLantern()
    {
        pressedCount++;
        Debug.Log($"�����ꂽ�Γ��Ă̐�: {pressedCount} / {requiredCount}");

        if (pressedCount >= requiredCount && !pillarReplaced)
        {
            pillarReplaced = true;
            ReplaceBrokenPillar();

            if (altar != null)
            {
                altar.ActivateRunes();
            }
        }
    }

    private void ReplaceBrokenPillar()
    {
        if (brokenPillarObject == null || glowingPillarPrefab == null)
        {
            Debug.LogError("�ݒ�~�X: ��ꂽ���܂��͌��钌�����ݒ�ł��B");
            return;
        }

        Vector3 pos = brokenPillarObject.transform.position;
        Quaternion rot = brokenPillarObject.transform.rotation;

        Destroy(brokenPillarObject);
        Instantiate(glowingPillarPrefab, pos, rot);
        Debug.Log("���̍����ւ������I");
    }
}