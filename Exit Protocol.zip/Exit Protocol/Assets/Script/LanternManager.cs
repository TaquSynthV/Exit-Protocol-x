﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class LanternManager : MonoBehaviour
{
    public static LanternManager Instance { get; private set; }

    public int requiredCount = 6;
    public GameObject brokenPillarObject;
    public GameObject glowingPillarPrefab;
    public PropsAltar altar;

    [Header("Audio")]
    [SerializeField] private AudioClip pillarRestoreSE;
    [SerializeField] private AudioMixerGroup mixerGroup;
    [SerializeField] private float seVolume = 1.0f;

    private bool pillarReplaced = false;

    private List<int> correctOrder = new(); // 正しい押す順番のリスト
    private int currentIndex = 0;
    private List<StoneLanternButton> allLanterns = new();

    private void Awake()
    {
        if (Instance != null) Destroy(gameObject);
        Instance = this;

        GenerateRandomOrder();
    }

    private void Start()
    {
        allLanterns = new List<StoneLanternButton>(
            FindObjectsByType<StoneLanternButton>(FindObjectsSortMode.None)
        );
    }

    private void GenerateRandomOrder()
    {
        correctOrder.Clear();
        for (int i = 0; i < requiredCount; i++)
        {
            correctOrder.Add(i);
        }

        // 順番シャッフル
        for (int i = 0; i < correctOrder.Count; i++)
        {
            int rand = Random.Range(i, correctOrder.Count);
            (correctOrder[i], correctOrder[rand]) = (correctOrder[rand], correctOrder[i]);
        }

        Debug.Log("石灯籠の正解順: " + string.Join(", ", correctOrder));
    }

    public void CheckLanternInput(int pressedID, StoneLanternButton button)
    {
        if (pillarReplaced) return;

        // ✅ すでに正しく押された灯籠は無視（重複防止）
        if (currentIndex < correctOrder.Count && pressedID == correctOrder[currentIndex])
        {
            currentIndex++;
            ChatLogger.Instance?.Log($"正解の灯籠を押した！（{currentIndex}/{requiredCount}）", "lantern");

            if (currentIndex >= requiredCount)
            {
                pillarReplaced = true;
                ReplaceBrokenPillar();
                altar?.ActivateRunes();
                ChatLogger.Instance?.Log("正しい順番で押した！柱が復活！", "lantern");
            }
        }
        else
        {
            // ✅ 間違ってもリセットしない・再挑戦できる
            ChatLogger.Instance?.Log("順番通りに押してください。", "lantern-warning");
        }
    }



    private void ReplaceBrokenPillar()
    {
        if (brokenPillarObject == null || glowingPillarPrefab == null)
        {
            Debug.LogError("柱または光る柱のプレハブが未設定です！");
            return;
        }

        Vector3 pos = brokenPillarObject.transform.position;
        Quaternion rot = brokenPillarObject.transform.rotation;

        Destroy(brokenPillarObject);
        Instantiate(glowingPillarPrefab, pos, rot);

        PlayPillarRestoreSE(pos);
    }

    private void PlayPillarRestoreSE(Vector3 position)
    {
        if (pillarRestoreSE == null) return;

        GameObject seObject = new GameObject("TempPillarSE");
        seObject.transform.position = position;

        AudioSource audioSource = seObject.AddComponent<AudioSource>();
        audioSource.clip = pillarRestoreSE;
        audioSource.volume = seVolume;
        audioSource.spatialBlend = 0f;

        if (mixerGroup != null)
            audioSource.outputAudioMixerGroup = mixerGroup;

        audioSource.Play();
        Destroy(seObject, pillarRestoreSE.length);
    }
}
