using UnityEngine;

public class PlateManager : MonoBehaviour
{
    public static PlateManager Instance { get; private set; }

    [SerializeField] private int requiredPlateCount = 3;
    private int currentPressedCount = 0;

    private void Awake()
    {
        if (Instance != null) Destroy(gameObject);
        Instance = this;
    }

    public void RegisterPlatePress()
    {
        currentPressedCount++;
        UpdateLog();
    }

    public void RegisterPlateRelease()
    {
        currentPressedCount = Mathf.Max(0, currentPressedCount - 1);
        UpdateLog();
    }

    public bool AreAllPlatesPressed()
    {
        return currentPressedCount >= requiredPlateCount;
    }

    private void UpdateLog()
    {
        ChatLogger.Instance?.Log($"�����������ꂽ�I�i{currentPressedCount}/{requiredPlateCount}�j", "plateCount");
    }
}
