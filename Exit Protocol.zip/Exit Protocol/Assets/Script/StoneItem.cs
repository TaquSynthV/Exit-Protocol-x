﻿using UnityEngine;
using UnityEngine.Audio;

public class StoneItem : MonoBehaviour, IInteractable
{
    [Header("Audio Settings")]
    public AudioClip pickupSound;                     // 拾う音
    public AudioMixerGroup audioMixerGroup;           // AudioMixerGroup を設定可能にする
    [Range(0f, 1f)] public float volume = 1.0f;        // 音量（0.0〜1.0）

    private bool pickedUp = false;

    public void Interact()
    {
        if (pickedUp) return;

        pickedUp = true;
        GameManager.Instance.AddStone();

        // 効果音を再生
        PlaySEWithMixer(pickupSound, transform.position, audioMixerGroup);

        // 0.2秒後にアイテム非表示
        Invoke(nameof(HideItem), 0.2f);
    }

    private void HideItem()
    {
        gameObject.SetActive(false);
    }

    private void PlaySEWithMixer(AudioClip clip, Vector3 position, AudioMixerGroup mixer)
    {
        if (clip == null) return;

        GameObject audioObj = new GameObject("TempStoneSE");
        audioObj.transform.position = position;

        AudioSource audioSource = audioObj.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = volume;
        audioSource.spatialBlend = 0f;
        audioSource.outputAudioMixerGroup = mixer;

        audioSource.Play();
        Destroy(audioObj, clip.length);
    }
}
