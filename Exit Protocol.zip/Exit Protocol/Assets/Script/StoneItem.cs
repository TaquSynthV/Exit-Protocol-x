using UnityEngine;

public class StoneItem : MonoBehaviour, IInteractable
{
    private bool pickedUp = false;

    public void Interact()
    {
        if (pickedUp) return;

        pickedUp = true;
        GameManager.Instance.AddStone();
        gameObject.SetActive(false);
    }
}