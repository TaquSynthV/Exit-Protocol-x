using System;
using System.Collections.Generic;

[Serializable]
public class SaveData
{
    public int runeCount;
    public bool hasKey;
    public int stoneCount;

    public bool hasOpenedChest;
    public bool hasOpenedRuneChest;
    public bool goddessUsed;
    public bool pillarFixed;
    public bool isPlayerPoweredUp;


    public int runePotIndex = -1;
    public bool runePotCollected = false;

    public List<string> destroyedObjects = new List<string>();
    public List<string> collectedStones = new List<string>();
    public List<string> pressedLanterns = new List<string>();
}
