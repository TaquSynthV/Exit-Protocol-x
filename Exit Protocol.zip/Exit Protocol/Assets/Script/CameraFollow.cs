﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Cainos.PixelArtTopDown_Basic
{
    // let camera follow target
    public class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public float lerpSpeed = 1.0f;

        private Vector3 offset;

        private Vector3 targetPos;

        private void Start()
        {
            if (target == null) return;

            // offset は0にする（カメラの中心にtargetを固定するため）
            offset = Vector3.zero;
        }

        private void Update()
        {
            if (target == null) return;

            // ターゲット位置そのものを目指す
            targetPos = target.position + offset;

            // カメラのZ軸位置は維持する（offsetに含めていないので別途固定）
            targetPos.z = transform.position.z;

            // 線形補間でなめらかに追従
            transform.position = Vector3.Lerp(transform.position, targetPos, lerpSpeed * Time.deltaTime);
        }
    }
}
