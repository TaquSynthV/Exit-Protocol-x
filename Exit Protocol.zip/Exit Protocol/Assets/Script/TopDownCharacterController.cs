﻿using UnityEngine;
using UnityEngine.Audio;

namespace Cainos.PixelArtTopDown_Basic
{
    public class TopDownCharacterController : MonoBehaviour
    {
        public float speed;
        public float interactRange = 1f;

        public GameObject attackHitboxPrefab;
        public float attackDuration = 0.2f;

        public AudioClip footstepSE;
        public AudioMixerGroup mixerGroup;
        public float footstepVolume = 0.4f;

        private AudioSource footstepSource;
        private Animator animator;
        private Vector2 lastDirection = Vector2.down;
        private Rigidbody2D rb;

        private PushableObject pullingTarget = null;

        private void Start()
        {
            animator = GetComponent<Animator>();
            rb = GetComponent<Rigidbody2D>();

            footstepSource = gameObject.AddComponent<AudioSource>();
            footstepSource.clip = footstepSE;
            footstepSource.loop = true;
            footstepSource.volume = footstepVolume;
            footstepSource.playOnAwake = false;
            footstepSource.spatialBlend = 0f;

            if (mixerGroup != null)
            {
                footstepSource.outputAudioMixerGroup = mixerGroup;
            }
        }

        [System.Obsolete]
        private void Update()
        {
            Vector2 dir = Vector2.zero;

            if (Input.GetKey(KeyCode.A)) { dir.x = -1; animator.SetInteger("Direction", 3); }
            else if (Input.GetKey(KeyCode.D)) { dir.x = 1; animator.SetInteger("Direction", 2); }

            if (Input.GetKey(KeyCode.W)) { dir.y = 1; animator.SetInteger("Direction", 1); }
            else if (Input.GetKey(KeyCode.S)) { dir.y = -1; animator.SetInteger("Direction", 0); }

            if (dir != Vector2.zero) lastDirection = dir;

            dir.Normalize();
            rb.velocity = speed * dir;

            // 足音の再生・停止処理
            if (dir.magnitude > 0)
            {
                if (!footstepSource.isPlaying && footstepSE != null)
                    footstepSource.Play();
            }
            else
            {
                if (footstepSource.isPlaying)
                    footstepSource.Stop();
            }

            // ★ マウス左クリック（押しながら移動で引っ張る）
            if (Input.GetMouseButton(0))
            {
                if (pullingTarget == null)
                    TryStartPull();
            }
            else
            {
                if (pullingTarget != null)
                {
                    pullingTarget.StopPull();
                    pullingTarget = null;
                }
            }

            // インタラクト・攻撃
            if (Input.GetKeyDown(KeyCode.E)) Interact();
            if (Input.GetKeyDown(KeyCode.Q)) Attack();
        }

        private void Interact()
        {
            Vector2 rayDirection = GetDirectionVector();
            Vector2 origin = (Vector2)transform.position + rayDirection * 0.4f;
            RaycastHit2D hit = Physics2D.Raycast(origin, rayDirection, interactRange);
            Debug.DrawRay(origin, rayDirection * interactRange, Color.red, 0.5f);

            if (hit.collider != null)
            {
                IInteractable interactable = hit.collider.GetComponent<IInteractable>();
                if (interactable != null) interactable.Interact();
            }
        }

        private void Attack()
        {
            Vector2 attackDir = GetDirectionVector();
            Vector2 spawnPos = (Vector2)transform.position + attackDir * 0.5f;
            GameObject attack = Instantiate(attackHitboxPrefab, spawnPos, Quaternion.identity);
            Destroy(attack, attackDuration);
        }

        private Vector2 GetDirectionVector()
        {
            int direction = animator.GetInteger("Direction");
            return direction switch
            {
                0 => Vector2.down,
                1 => Vector2.up,
                2 => Vector2.right,
                3 => Vector2.left,
                _ => Vector2.down
            };
        }

        private void TryStartPull()
        {
            Vector2 rayDirection = GetDirectionVector();
            Vector2 origin = (Vector2)transform.position + rayDirection * 0.4f;
            RaycastHit2D hit = Physics2D.Raycast(origin, rayDirection, interactRange);

            if (hit.collider != null)
            {
                PushableObject pushable = hit.collider.GetComponent<PushableObject>();
                if (pushable != null)
                {
                    pullingTarget = pushable;
                    pushable.StartPull(transform);
                }
            }
        }
    }
}
