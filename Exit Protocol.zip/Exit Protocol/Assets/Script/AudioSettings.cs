using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class AudioSettings : MonoBehaviour
{
    public AudioMixer mixer;
    public Slider bgmSlider;
    public Slider seSlider;

    void Start()
    {
        bgmSlider.onValueChanged.AddListener(SetBGMVolume);
        seSlider.onValueChanged.AddListener(SetSEVolume);
    }

    public void SetBGMVolume(float value)
    {
        mixer.SetFloat("BGMVolume", Mathf.Log10(Mathf.Clamp(value, 0.001f, 1f)) * 20);
    }

    public void SetSEVolume(float value)
    {
        mixer.SetFloat("SEVolume", Mathf.Log10(Mathf.Clamp(value, 0.001f, 1f)) * 20);
    }
}
