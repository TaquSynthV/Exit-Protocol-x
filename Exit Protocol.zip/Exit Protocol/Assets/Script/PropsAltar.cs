﻿using UnityEngine;

public class PropsAltar : MonoBehaviour
{
    public SpriteRenderer[] runeRenderers;
    public float colorChangeSpeed = 2.0f;
    public GameObject gatePrefab;
    public Transform gateSpawnPoint;

    private float targetAlpha = 0f;
    private bool isActivated = false;
    private bool gateSpawned = false;
    private bool playerOnAltar = false;

    private void Start()
    {
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                var c = renderer.color;
                c.a = 0f;
                renderer.color = c;
            }
        }
    }

    private void Update()
    {
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                Color current = renderer.color;
                Color target = new Color(current.r, current.g, current.b, targetAlpha);
                renderer.color = Color.Lerp(current, target, Time.deltaTime * colorChangeSpeed);
            }
        }

        if (playerOnAltar && isActivated && GameManager.Instance.hasRune && Input.GetKeyDown(KeyCode.E))
        {
            TrySpawnGate();
        }
    }

    public void ActivateRunes()
    {
        isActivated = true;
        targetAlpha = 1f;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerOnAltar = true;
            if (!isActivated) targetAlpha = 1f;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerOnAltar = false;
            if (!isActivated) targetAlpha = 0f;
        }
    }

    private void TrySpawnGate()
    {
        if (gateSpawned) return;
        if (gatePrefab == null || gateSpawnPoint == null) return;

        Instantiate(gatePrefab, gateSpawnPoint.position, Quaternion.identity);
        gateSpawned = true;
        Debug.Log("ゲート（ポータル）を出現させました！");
    }
}