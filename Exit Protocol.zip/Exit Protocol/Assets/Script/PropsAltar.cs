﻿using UnityEngine;

public class PropsAltar : MonoBehaviour
{
    public SpriteRenderer[] runeRenderers;
    public float colorChangeSpeed = 2.0f;
    public GameObject gameClearUI;

    private float targetAlpha = 0f;
    private bool isActivated = false;
    private bool gameCleared = false;

    private void Start()
    {
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                var c = renderer.color;
                c.a = 0f;
                renderer.color = c;
            }
        }

        if (gameClearUI != null)
        {
            gameClearUI.SetActive(false);
        }
    }

    private void Update()
    {
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                Color current = renderer.color;
                Color target = new Color(current.r, current.g, current.b, targetAlpha);
                renderer.color = Color.Lerp(current, target, Time.deltaTime * colorChangeSpeed);
            }
        }
    }

    public void ActivateRunes()
    {
        isActivated = true;
        targetAlpha = 1f;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (gameCleared) return;
        if (!isActivated) return;

        // ★ 条件をruneCount >= 2 に変更
        if (other.CompareTag("Player") && GameManager.Instance.runeCount >= 4)
        {
            GameClear();
        }
    }

    private void GameClear()
    {
        gameCleared = true;

        if (gameClearUI != null)
        {
            gameClearUI.SetActive(true);
        }
        else
        {
            Debug.LogWarning("GameClearUIが設定されていません！");
        }

        Time.timeScale = 0f;
        Debug.Log("ゲームクリア！");
    }
}
