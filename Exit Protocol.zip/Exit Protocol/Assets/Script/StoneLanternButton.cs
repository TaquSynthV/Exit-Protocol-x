using UnityEngine;

public class StoneLanternButton : MonoBehaviour, IInteractable
{
    private bool isPressed = false;

    public void Interact()
    {
        if (isPressed) return;

        isPressed = true;
        Debug.Log("�Γ��ẴX�C�b�`���������I");
        LanternManager.Instance.RegisterPressedLantern();
    }
}