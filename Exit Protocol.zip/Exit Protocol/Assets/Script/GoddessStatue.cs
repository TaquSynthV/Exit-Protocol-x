using UnityEngine;

public class GoddessStatue : MonoBehaviour, IInteractable
{
    public GameObject[] stairsToActivate;
    private bool hasActivated = false;

    public void Interact()
    {
        if (hasActivated) return;

        hasActivated = true;
        Debug.Log("���_���𒲂ׂ��I�K�i�����ꂽ�I");

        foreach (GameObject stair in stairsToActivate)
        {
            if (stair != null)
            {
                stair.SetActive(true);
            }
        }
    }
}