using UnityEngine;
using UnityEditor;
using System.IO;

public class PortalPrefabCreator : EditorWindow
{
    private Texture2D spriteSheet;
    private int frameWidth = 64;
    private int frameHeight = 96;
    private float frameRate = 6f;

    [MenuItem("Tools/Create Portal Prefab")]
    public static void ShowWindow()
    {
        GetWindow<PortalPrefabCreator>("Portal Prefab Creator");
    }

    [System.Obsolete]
    private void OnGUI()
    {
        GUILayout.Label("�|�[�^���X�v���C�g�V�[�g����v���n�u����������", EditorStyles.boldLabel);

        spriteSheet = (Texture2D)EditorGUILayout.ObjectField("�X�v���C�g�V�[�g", spriteSheet, typeof(Texture2D), false);
        frameWidth = EditorGUILayout.IntField("�t���[����", frameWidth);
        frameHeight = EditorGUILayout.IntField("�t���[������", frameHeight);
        frameRate = EditorGUILayout.FloatField("�A�j��FPS", frameRate);

        if (GUILayout.Button("����"))
        {
            if (spriteSheet == null)
            {
                Debug.LogError("�X�v���C�g�V�[�g���I������Ă��܂���B");
                return;
            }

            CreatePortalAnimation(spriteSheet, frameWidth, frameHeight, frameRate);
        }
    }

    [System.Obsolete]
    private void CreatePortalAnimation(Texture2D texture, int width, int height, float fps)
    {
        string path = AssetDatabase.GetAssetPath(texture);
        TextureImporter ti = AssetImporter.GetAtPath(path) as TextureImporter;

        if (ti == null)
        {
            Debug.LogError("TextureImporter �擾���s");
            return;
        }

        // �X�v���C�g�����ݒ�
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Multiple;
        ti.filterMode = FilterMode.Point;

        int cols = texture.width / width;
        int rows = texture.height / height;
        SpriteMetaData[] metas = new SpriteMetaData[cols * rows];

        for (int y = 0; y < rows; y++)
        {
            for (int x = 0; x < cols; x++)
            {
                int i = y * cols + x;
                SpriteMetaData meta = new SpriteMetaData();
                meta.name = $"portal_{i}";
                meta.rect = new Rect(x * width, texture.height - (y + 1) * height, width, height);
                meta.pivot = new Vector2(0.5f, 0.5f);
                meta.alignment = (int)SpriteAlignment.Center;
                metas[i] = meta;
            }
        }

        ti.spritesheet = metas;
        AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);

        // �X�v���C�g�̎擾
        Object[] sprites = AssetDatabase.LoadAllAssetRepresentationsAtPath(path);
        Sprite[] spriteArray = System.Array.ConvertAll(sprites, item => (Sprite)item);

        // �A�j���[�V�����N���b�v�쐬
        string folder = Path.GetDirectoryName(path);
        string animPath = $"{folder}/Portal.anim";
        AnimationClip clip = new AnimationClip();
        clip.frameRate = fps;

        EditorCurveBinding spriteBinding = new EditorCurveBinding
        {
            type = typeof(SpriteRenderer),
            path = "",
            propertyName = "m_Sprite"
        };

        ObjectReferenceKeyframe[] keyFrames = new ObjectReferenceKeyframe[spriteArray.Length];
        for (int i = 0; i < spriteArray.Length; i++)
        {
            keyFrames[i] = new ObjectReferenceKeyframe
            {
                time = i / fps,
                value = spriteArray[i]
            };
        }

        AnimationUtility.SetObjectReferenceCurve(clip, spriteBinding, keyFrames);
        AssetDatabase.CreateAsset(clip, animPath);

        // Animator Controller �쐬
        string controllerPath = $"{folder}/Portal.controller";
        var controller = UnityEditor.Animations.AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
        controller.AddMotion(clip);

        // �v���n�u�쐬
        GameObject portal = new GameObject("Portal");
        var sr = portal.AddComponent<SpriteRenderer>();
        var animator = portal.AddComponent<Animator>();
        animator.runtimeAnimatorController = controller;

        string prefabPath = $"{folder}/Portal.prefab";
        PrefabUtility.SaveAsPrefabAsset(portal, prefabPath);
        DestroyImmediate(portal);

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        Debug.Log("�|�[�^���v���n�u���쐬���܂����I");
    }
}
