using UnityEngine;

public class BrokenPillar : MonoBehaviour, IInteractable
{
    public GameObject fixedPillarPrefab;
    public Transform goddessStatue;
    public GameObject treasureChestPrefab;

    private bool isFixed = false;

    public void Interact()
    {
        if (isFixed) return;

        if (GameManager.Instance.stoneCount >= 6)
        {
            isFixed = true;
            Debug.Log("�Α����C�������I");

            Instantiate(fixedPillarPrefab, transform.position, transform.rotation);
            Destroy(gameObject);

            if (goddessStatue != null)
            {
                Vector3 originalPos = goddessStatue.position;
                goddessStatue.position += Vector3.right * 1.2f;
                Debug.Log("���_�����E�ɓ������I");

                if (treasureChestPrefab != null)
                {
                    Instantiate(treasureChestPrefab, originalPos, Quaternion.identity);
                    Debug.Log("�󔠂��o�������I");
                }
            }
        }
        else
        {
            Debug.Log($"�΂�����Ȃ��c�i{GameManager.Instance.stoneCount} / 6�j");
        }
    }
}