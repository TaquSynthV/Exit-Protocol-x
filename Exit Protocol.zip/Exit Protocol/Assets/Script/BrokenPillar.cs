﻿using UnityEngine;
using UnityEngine.Audio;

public class BrokenPillar : MonoBehaviour, IInteractable
{
    [Header("Fix Settings")]
    public GameObject fixedPillarPrefab;
    public Transform goddessStatue;
    public GameObject treasureChestPrefab;

    [Header("Audio Settings")]
    public AudioClip fixPillarSE;                          // 柱修復音
    public AudioClip moveGoddessSE;                        // 女神像移動音
    public AudioMixerGroup audioMixerGroup;                // ミキサー
    [Range(0f, 1f)] public float seVolume = 1.0f;           // 音量

    [Header("Timing Settings")]
    [Range(0.1f, 10f)] public float fixSEPlayDuration = 1.0f;

    private bool isFixed = false;

    public void Interact()
    {
        if (isFixed) return;

        if (GameManager.Instance.stoneCount >= 6)
        {
            isFixed = true;
            Debug.Log("石像を修復した！");
            ChatLogger.Instance?.Log("石像を修復した！");

            PlaySE(fixPillarSE, transform.position, audioMixerGroup, fixSEPlayDuration);

            Instantiate(fixedPillarPrefab, transform.position, transform.rotation);
            Destroy(gameObject);

            if (goddessStatue != null)
            {
                Vector3 originalPos = goddessStatue.position;
                goddessStatue.position += Vector3.right * 1.2f;
                Debug.Log("女神像が右に動いた！");
                ChatLogger.Instance?.Log("女神像が動いた！");

                PlaySE(moveGoddessSE, goddessStatue.position, audioMixerGroup);

                if (treasureChestPrefab != null)
                {
                    Instantiate(treasureChestPrefab, originalPos, Quaternion.identity);
                    Debug.Log("宝箱が出現した！");
                    ChatLogger.Instance?.Log("女神像の裏に宝箱が現れた！");
                }
            }
        }
        else
        {
            int count = GameManager.Instance.stoneCount;
            Debug.Log($"石が足りない…（{count} / 6）");
            ChatLogger.Instance?.Log($"石が足りない…（{count} / 6）", "stoneCheck");
        }
    }

    private void PlaySE(AudioClip clip, Vector3 position, AudioMixerGroup mixer, float durationOverride = -1f)
    {
        if (clip == null) return;

        GameObject audioObj = new GameObject("TempSE");
        audioObj.transform.position = position;

        AudioSource audioSource = audioObj.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = seVolume;
        audioSource.outputAudioMixerGroup = mixer;
        audioSource.spatialBlend = 0f;

        audioSource.Play();
        StartCoroutine(StopAndDestroyAfter(audioSource, audioObj, durationOverride > 0f ? durationOverride : clip.length));
    }

    private System.Collections.IEnumerator StopAndDestroyAfter(AudioSource source, GameObject obj, float delay)
    {
        yield return new WaitForSeconds(delay);

        if (source != null)
        {
            source.Stop();
        }

        Destroy(obj);
    }
}
