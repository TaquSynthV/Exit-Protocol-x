﻿using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public bool hasKey = false;
    public int stoneCount = 0;
    public int runeCount = 0;
    public bool isPlayerPoweredUp = false;
    public bool canPowerUpPlayer = false;

    // その他進行状態
    public bool hasOpenedChest;
    public bool hasOpenedRuneChest;
    public bool goddessUsed;
    public bool pillarFixed;

    public int runePotIndex = -1;
    public bool runePotCollected = false;

    public List<string> destroyedObjects = new();
    public List<string> collectedStones = new();
    public List<string> pressedLanterns = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        LoadGame(); // 起動時に自動ロード
    }

    public void AddStone()
    {
        stoneCount++;
        Debug.Log($"石を拾った！現在の数: ({stoneCount}/6)");
        ChatLogger.Instance?.Log($"石を拾った！({stoneCount}/6)", "stone");
    }

    public void AddRune()
    {
        runeCount++;
        Debug.Log($"ルーンを手に入れた！現在の数: ({runeCount}/3)");
        ChatLogger.Instance?.Log($"ルーンを手に入れた！（{runeCount}/3）", "rune");
    }

    /// <summary>
    /// プレイヤーを強化状態にする（1回のみ）
    /// </summary>
    public void PowerUpPlayer()
    {
        if (isPlayerPoweredUp)
        {
            Debug.Log("すでにプレイヤーは強化されています。");
            return;
        }

        isPlayerPoweredUp = true;
        Debug.Log("プレイヤーが強化された！");
        ChatLogger.Instance?.Log("プレイヤーが強化された！");

        // 必要であれば演出やUI演出をここに追加
    }

    /// <summary>
    /// ゲームの状態をセーブ
    /// </summary>
    public void SaveGame()
    {
        SaveData data = new SaveData
        {
            hasKey = hasKey,
            stoneCount = stoneCount,
            runeCount = runeCount,
            isPlayerPoweredUp = isPlayerPoweredUp, // ← 追加
            hasOpenedChest = hasOpenedChest,
            hasOpenedRuneChest = hasOpenedRuneChest,
            goddessUsed = goddessUsed,
            pillarFixed = pillarFixed,
            runePotIndex = runePotIndex,
            runePotCollected = runePotCollected,
            destroyedObjects = new List<string>(destroyedObjects),
            collectedStones = new List<string>(collectedStones),
            pressedLanterns = new List<string>(pressedLanterns)
        };

        SaveManager.Save(data);
    }

    /// <summary>
    /// ゲームの状態をロード
    /// </summary>
    public void LoadGame()
    {
        SaveData data = SaveManager.Load();

        hasKey = data.hasKey;
        stoneCount = data.stoneCount;
        runeCount = data.runeCount;
        isPlayerPoweredUp = data.isPlayerPoweredUp; // ← 追加
        hasOpenedChest = data.hasOpenedChest;
        hasOpenedRuneChest = data.hasOpenedRuneChest;
        goddessUsed = data.goddessUsed;
        pillarFixed = data.pillarFixed;
        runePotIndex = data.runePotIndex;
        runePotCollected = data.runePotCollected;
        destroyedObjects = new List<string>(data.destroyedObjects);
        collectedStones = new List<string>(data.collectedStones);
        pressedLanterns = new List<string>(data.pressedLanterns);
    }
}
