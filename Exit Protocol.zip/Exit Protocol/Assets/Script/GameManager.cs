using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public bool hasKey = false;
    public bool hasRune = false;  // ���[���擾�t���O

    public int stoneCount = 0;    // �΂̏�����

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void AddStone()
    {
        stoneCount++;
        Debug.Log("�΂��E�����I���݂̐�: " + stoneCount);
    }
}
