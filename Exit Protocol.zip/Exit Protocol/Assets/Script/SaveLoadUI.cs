using UnityEngine;
using UnityEngine.UI;

public class SaveLoadUI : MonoBehaviour
{
    public Button saveButton;
    public Button loadButton;

    void Start()
    {
        saveButton.onClick.AddListener(() =>
        {
            SaveSystem.Save(GameManager.Instance.GetCurrentSaveData());
            ChatLogger.Instance?.Log("�Q�[�����Z�[�u���܂����I");
        });

        loadButton.onClick.AddListener(() =>
        {
            var data = SaveSystem.Load();
            if (data != null)
            {
                GameManager.Instance.LoadFromData(data);
                ChatLogger.Instance?.Log("�Q�[�������[�h���܂����I");
            }
        });
    }
}
