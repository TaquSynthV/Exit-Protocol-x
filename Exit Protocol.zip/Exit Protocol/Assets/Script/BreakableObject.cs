﻿using UnityEngine;
using UnityEngine.Audio;

public class BreakableObject : MonoBehaviour
{
    [Header("References")]
    public GameObject brokenVersionPrefab;
    public GameObject dropItemPrefab;

    [Header("Audio")]
    public AudioClip breakSE;
    public AudioMixerGroup mixerGroup;
    [Range(0f, 1f)] public float seVolume = 1.0f;
    public float breakDelay = 0.1f;

    [Header("Item Contents")]
    public bool containsRune = false;

    private bool isBreaking = false;

    public void Break()
    {
        if (isBreaking) return;
        isBreaking = true;

        // 効果音を先に再生
        PlaySEWithMixer(breakSE, transform.position, mixerGroup);

        // 少し遅れて破壊処理
        Invoke(nameof(HandleBreak), breakDelay);
    }

    private void HandleBreak()
    {
        if (brokenVersionPrefab != null)
        {
            Instantiate(brokenVersionPrefab, transform.position, transform.rotation);
        }

        if (dropItemPrefab != null)
        {
            Instantiate(dropItemPrefab, transform.position, Quaternion.identity);
        }

        if (containsRune)
        {
            GameManager.Instance.AddRune();
            Debug.Log("壺やタルからルーンを手に入れた！");
        }

        Destroy(gameObject);
    }

    private void PlaySEWithMixer(AudioClip clip, Vector3 position, AudioMixerGroup mixer)
    {
        if (clip == null) return;

        GameObject seObject = new GameObject("TempBreakSE");
        seObject.transform.position = position;

        AudioSource audioSource = seObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = seVolume;
        audioSource.spatialBlend = 0f;

        if (mixer != null)
        {
            audioSource.outputAudioMixerGroup = mixer;
        }

        audioSource.Play();
        Destroy(seObject, clip.length);
    }
}
