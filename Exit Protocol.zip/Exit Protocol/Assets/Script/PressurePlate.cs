using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class PressurePlate : MonoBehaviour
{
    public bool IsPressed => _pressingObjects.Count > 0;

    [SerializeField] private AudioClip pressSE;
    [SerializeField] private AudioMixerGroup mixerGroup;
    [SerializeField] private float seVolume = 1.0f;

    private readonly HashSet<Collider2D> _pressingObjects = new();

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Pushable") && !_pressingObjects.Contains(other))
        {
            _pressingObjects.Add(other);
            PlayPressSE();

            PlateManager.Instance?.RegisterPlatePress(); // ���ǉ�

            Debug.Log($"�����������ꂽ�I�i{other.name}�j");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Pushable"))
        {
            _pressingObjects.Remove(other);
            Debug.Log($"�������痣�ꂽ�I�i{other.name}�j");

            if (_pressingObjects.Count == 0)
            {
                PlateManager.Instance?.RegisterPlateRelease(); // ���ǉ�
            }
        }
    }


    private void PlayPressSE()
    {
        if (pressSE != null)
        {
            GameObject seObject = new GameObject("TempPressureSE");
            seObject.transform.position = transform.position;

            AudioSource audioSource = seObject.AddComponent<AudioSource>();
            audioSource.clip = pressSE;
            audioSource.volume = seVolume;
            audioSource.spatialBlend = 0f; // 2D��

            if (mixerGroup != null)
            {
                audioSource.outputAudioMixerGroup = mixerGroup;
            }

            audioSource.Play();
            Destroy(seObject, pressSE.length);
        }
        else
        {
            Debug.LogWarning("������SE(AudioClip)���ݒ肳��Ă��܂���B");
        }
    }
}
