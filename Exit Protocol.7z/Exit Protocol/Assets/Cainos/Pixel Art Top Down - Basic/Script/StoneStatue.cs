using UnityEngine;

public class StoneStatue : MonoBehaviour, IInteractable
{
    public GameObject repairedVersion;
    public int stonesRequired = 6;
    private bool isRepaired = false;

    public void Interact()
    {
        if (isRepaired) return;

        if (Inventory.Instance.UseStones(stonesRequired))
        {
            isRepaired = true;
            repairedVersion.SetActive(true);
            gameObject.SetActive(false);
            GameEvents.StatueRepaired();
        }
    }
}
