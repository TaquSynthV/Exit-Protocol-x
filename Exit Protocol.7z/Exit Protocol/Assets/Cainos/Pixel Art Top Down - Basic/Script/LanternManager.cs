using UnityEngine;

public class LanternManager : MonoBehaviour
{
    public static LanternManager Instance;

    private int pressedCount = 0;
    private int totalLanterns = 6;

    public GameObject brokenPillar;       // PF Props Rune Pillar Broken
    public GameObject fixedPillarPrefab;  // PF Props Rune Pillar X2

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void RegisterPressedLantern()
    {
        pressedCount++;
        Debug.Log("�����ꂽ���Đ�: " + pressedCount + " / " + totalLanterns);

        if (pressedCount >= totalLanterns)
        {
            ReplaceBrokenPillar();
        }
    }

    private void ReplaceBrokenPillar()
    {
        if (brokenPillar != null && fixedPillarPrefab != null)
        {
            Instantiate(fixedPillarPrefab, brokenPillar.transform.position, brokenPillar.transform.rotation);
            Destroy(brokenPillar);
            Debug.Log("�������������I");
        }
    }
}
