using UnityEngine;

public class PillarGlowTrigger : MonoBehaviour
{
    public SpriteRenderer pillarRenderer;
    public Sprite glowSprite;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            pillarRenderer.sprite = glowSprite;
        }
    }
}
