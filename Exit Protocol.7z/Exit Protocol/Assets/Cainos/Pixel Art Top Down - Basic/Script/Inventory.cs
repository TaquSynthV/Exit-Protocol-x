﻿using System;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public static Inventory Instance { get; private set; }

    public int stoneCount = 0;
    public bool hasKey = false; // 🔸 追加: 鍵を持っているか
    internal bool hasRune;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public void AddStone()
    {
        stoneCount++;
    }

    public bool UseStones(int amount)
    {
        if (stoneCount >= amount)
        {
            stoneCount -= amount;
            return true;
        }
        return false;
    }

    // 🔽 追加：鍵を取得する
    public void AddKey()
    {
        hasKey = true;
    }

    // 🔽 追加：鍵を使う
    public bool UseKey()
    {
        if (hasKey)
        {
            hasKey = false;
            return true;
        }
        return false;
    }

    internal void AddRune()
    {
        throw new NotImplementedException();
    }
}
