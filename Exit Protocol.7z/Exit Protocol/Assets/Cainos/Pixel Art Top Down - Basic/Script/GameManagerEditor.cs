#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(GameManager))]
public class GameManagerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        GameManager gm = (GameManager)target;

        GUILayout.Space(10);
        EditorGUILayout.LabelField("=== Debug Controls ===", EditorStyles.boldLabel);

        if (GUILayout.Button("Add 6 Stones (Debug)"))
        {
            gm.AddStone(6);
        }

        if (GUILayout.Button("Repair Statue Now"))
        {
            gm.RepairStatue();
        }

        if (GUILayout.Button("Open Treasure Now"))
        {
            gm.OpenTreasure();
        }

        if (GUILayout.Button("Reset All Progress"))
        {
            gm.ResetProgress();
        }
    }
}
#endif
